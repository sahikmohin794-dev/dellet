package demo.Curd28;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Curd28Application {

	public static void main(String[] args) {
		SpringApplication.run(Curd28Application.class, args);
	}

}
