package demo.Curd28;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Curd28ApplicationTests {

	@Test
	void contextLoads() {
	}

}
